from django.urls import path
from . import views

urlpatterns = [
    # 🏠 HOME
    path('', views.home, name='home'),

    # 🔐 AUTH
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),

    # 🛒 CART
    path('cart/', views.cart_view, name='cart'),
    path('add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('increase/<int:cart_id>/', views.increase_qty, name='increase_qty'),
    path('decrease/<int:cart_id>/', views.decrease_qty, name='decrease_qty'),
   

    # ❤️ WISHLIST (IMPORTANT ADD)
    path('wishlist/<int:product_id>/', views.toggle_wishlist, name='wishlist'),

    # 💳 CHECKOUT
    path('checkout/', views.checkout, name='checkout'),

    # 📦 ORDERS
    path('orders/', views.orders, name='orders'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('order_history/', views.order_history, name='order_history'),
]
