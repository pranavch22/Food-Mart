from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

from .models import Product, Cart, Order, OrderItem, Wishlist
def order_history(request):
    if not request.user.is_authenticated:
        return redirect('login')

    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'order_history.html', {'orders': orders})


# 🏠 HOME (ONLY ONE FUNCTION)
def home(request):
    return render(request, 'index.html', {
        'fruits': Product.objects.filter(category='Fruits')[:5],
        'fruits_all': Product.objects.filter(category='Fruits'),

        'vegetables': Product.objects.filter(category='Vegetables')[:5],
        'vegetables_all': Product.objects.filter(category='Vegetables'),

        'dairy': Product.objects.filter(category='Dairy')[:5],
        'dairy_all': Product.objects.filter(category='Dairy'),

        'skincare': Product.objects.filter(category='Skincare')[:5],
        'skincare_all': Product.objects.filter(category='Skincare'),
    })


# 🔐 LOGIN
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password')

    return render(request, 'login.html')


# 🚪 LOGOUT
def user_logout(request):
    logout(request)
    return redirect('home')


# 🛒 ADD TO CART
@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    item, created = Cart.objects.get_or_create(
        user=request.user,
        product=product
    )

    if not created:
        item.quantity += 1
        item.save()

    return redirect('cart')


# 📦 CART PAGE
@login_required
def cart_view(request):
    items = Cart.objects.filter(user=request.user)
    total = sum(i.product.price * i.quantity for i in items)

    return render(request, 'cart.html', {
        'items': items,
        'total': total
    })


# ➕ INCREASE
@login_required
def increase_qty(request, cart_id):
    item = get_object_or_404(Cart, id=cart_id, user=request.user)
    item.quantity += 1
    item.save()
    return redirect('cart')


# ➖ DECREASE
@login_required
def decrease_qty(request, cart_id):
    item = get_object_or_404(Cart, id=cart_id, user=request.user)

    if item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()

    return redirect('cart')


# ❤️ WISHLIST TOGGLE
@login_required
def toggle_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    obj, created = Wishlist.objects.get_or_create(
        user=request.user,
        product=product
    )

    if not created:
        obj.delete()  # remove if already exists

    return redirect('home')


# 💳 CHECKOUT
@login_required
def checkout(request):
    items = Cart.objects.filter(user=request.user)
    total = sum(i.product.price * i.quantity for i in items)

    if request.method == 'POST':
        payment_method = request.POST.get('payment')

        order = Order.objects.create(
            user=request.user,
            total_amount=total,
            status="Pending"
        )

        for item in items:
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.price
            )

        items.delete()

        return redirect('orders')

    return render(request, 'checkout.html', {'total': total})


# 📦 ORDERS
@login_required
def orders(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'orders.html', {'orders': orders})

from django.db.models import Count
from django.utils.timezone import now, timedelta
from .models import Order


def dashboard(request):
    if not request.user.is_staff:
        return redirect('home')

    today = now().date()

    labels = []
    order_data = []

    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        count = Order.objects.filter(created_at__date=day).count()

        labels.append(day.strftime("%d %b"))
        order_data.append(count)

    total_orders = Order.objects.count()
    pending_orders = Order.objects.filter(status="Pending").count()
    delivered_orders = Order.objects.filter(status="Delivered").count()

    recent_orders = Order.objects.all().order_by('-created_at')[:8]

    return render(request, "dashboard.html", {
        "labels": labels,
        "order_data": order_data,
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        "delivered_orders": delivered_orders,
        "orders": recent_orders
    })
