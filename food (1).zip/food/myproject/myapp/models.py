from django.db import models
from django.contrib.auth.models import User


# 🛍️ PRODUCT
class Product(models.Model):
    CATEGORY_CHOICES = (
        ('Fruits', 'Fruits'),
        ('Vegetables', 'Vegetables'),
        ('Dairy', 'Dairy'),
        ('Skincare', 'Skincare'),
        ('Others', 'Others'),
    )

    name = models.CharField(max_length=100)
    price = models.IntegerField()
    image = models.URLField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='Others')

    def __str__(self):
        return self.name


# 🛒 CART
class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    class Meta:
        unique_together = ('user', 'product')  # ✅ prevent duplicate cart rows

    def __str__(self):
        return f"{self.user.username} - {self.product.name}"


# ❤️ WISHLIST
class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('user', 'product')  # ✅ no duplicate wishlist

    def __str__(self):
        return f"{self.user.username} ❤️ {self.product.name}"


# 📦 ORDER (main order)
class Order(models.Model):
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Delivered', 'Delivered'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total_amount = models.IntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - Order {self.id}"


# 📦 ORDER ITEMS (multiple products per order)
class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')  # ✅ important
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.IntegerField()

    def __str__(self):
        return f"{self.product.name} ({self.quantity})"